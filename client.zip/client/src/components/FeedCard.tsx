import { Heart, MessageCircle, Share2, MoreHorizontal, Bookmark } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export interface PostProps {
  id: string;
  author: {
    name: string;
    handle: string;
    avatar?: string;
    verified?: boolean;
  };
  content: string;
  category: "Request" | "Offer" | "Question" | "Social";
  timestamp: string;
  likes: number;
  comments: number;
  tags: string[];
  isLiked?: boolean;
}

const CategoryColors = {
  Request: "bg-orange-100 text-orange-700 hover:bg-orange-200",
  Offer: "bg-emerald-100 text-emerald-700 hover:bg-emerald-200",
  Question: "bg-blue-100 text-blue-700 hover:bg-blue-200",
  Social: "bg-pink-100 text-pink-700 hover:bg-pink-200",
};

export function FeedCard({ post }: { post: PostProps }) {
  return (
    <Card className="border-none shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden mb-4">
      <CardHeader className="flex flex-row items-start justify-between pb-3 space-y-0">
        <div className="flex gap-3">
          <Avatar className="w-10 h-10 border border-muted">
            <AvatarImage src={post.author.avatar} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {post.author.name[0]}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="flex items-center gap-1">
              <h3 className="font-bold text-sm leading-none">{post.author.name}</h3>
              <span className="text-muted-foreground text-xs">@{post.author.handle}</span>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-muted-foreground">{post.timestamp}</span>
              <span className="text-[10px] text-muted-foreground">•</span>
              <Badge variant="secondary" className={cn("text-[10px] px-1.5 py-0 h-5 font-medium border-none", CategoryColors[post.category])}>
                {post.category}
              </Badge>
            </div>
          </div>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
          <MoreHorizontal size={16} />
        </Button>
      </CardHeader>
      
      <CardContent className="pb-3 pt-0">
        <p className="text-sm md:text-base leading-relaxed whitespace-pre-wrap font-medium text-foreground/90">
          {post.content}
        </p>
        
        {post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-4">
            {post.tags.map(tag => (
              <span key={tag} className="text-xs text-primary font-medium bg-primary/5 px-2 py-1 rounded-md">
                #{tag}
              </span>
            ))}
          </div>
        )}
      </CardContent>

      <CardFooter className="border-t bg-muted/20 py-2 px-4 flex justify-between">
        <div className="flex gap-4">
          <Button variant="ghost" size="sm" className="h-8 px-2 gap-1.5 text-muted-foreground hover:text-pink-500 hover:bg-pink-50">
            <Heart size={18} className={post.isLiked ? "fill-pink-500 text-pink-500" : ""} />
            <span className="text-xs font-medium">{post.likes}</span>
          </Button>
          <Button variant="ghost" size="sm" className="h-8 px-2 gap-1.5 text-muted-foreground hover:text-blue-500 hover:bg-blue-50">
            <MessageCircle size={18} />
            <span className="text-xs font-medium">{post.comments}</span>
          </Button>
          <Button variant="ghost" size="sm" className="h-8 px-2 text-muted-foreground hover:text-primary hover:bg-primary/5">
            <Share2 size={18} />
          </Button>
        </div>
        <Button variant="ghost" size="sm" className="h-8 px-2 text-muted-foreground hover:text-primary hover:bg-primary/5">
          <Bookmark size={18} />
        </Button>
      </CardFooter>
    </Card>
  );
}
