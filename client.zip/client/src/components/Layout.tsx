import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Home, Search, PlusSquare, MessageCircle, User } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { icon: Home, label: "Home", path: "/" },
    { icon: Search, label: "Explore", path: "/explore" },
    { icon: PlusSquare, label: "Post", path: "/post", primary: true },
    { icon: MessageCircle, label: "Messages", path: "/messages" },
    { icon: User, label: "Profile", path: "/profile" },
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Main Content Area */}
      <main className="max-w-screen-md mx-auto min-h-screen relative">
        {children}
      </main>

      {/* Global Bottom Nav (For all screen sizes as per request) */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card/90 backdrop-blur-lg border-t z-50 px-6 py-3 flex justify-between items-center safe-area-pb shadow-[0_-4px_12px_rgba(0,0,0,0.05)]">
        {navItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a
              className={cn(
                "flex flex-col items-center gap-1 transition-all duration-200",
                location === item.path
                  ? "text-primary scale-110"
                  : "text-muted-foreground hover:text-secondary",
              )}
            >
              {item.primary ? (
                <div className="bg-primary text-primary-foreground p-3 rounded-2xl -mt-8 shadow-lg shadow-primary/30 border-4 border-background transform transition-transform hover:scale-110 active:scale-95">
                  <item.icon size={24} />
                </div>
              ) : (
                <>
                  <div
                    className={cn(
                      "p-1 rounded-lg transition-colors",
                      location === item.path
                        ? "bg-primary/10"
                        : "group-hover:bg-accent/20",
                    )}
                  >
                    <item.icon
                      size={22}
                      strokeWidth={location === item.path ? 2.5 : 2}
                    />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider">
                    {item.label}
                  </span>
                </>
              )}
            </a>
          </Link>
        ))}
      </nav>
    </div>
  );
}
