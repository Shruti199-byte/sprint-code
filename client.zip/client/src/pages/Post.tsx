import { useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { X, Image as ImageIcon, MapPin, Hash } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function Post() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("request");
  const [tags, setTags] = useState<string[]>([]);
  const [currentTag, setCurrentTag] = useState("");

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && currentTag.trim()) {
      e.preventDefault();
      if (!tags.includes(currentTag.trim())) {
        setTags([...tags, currentTag.trim()]);
      }
      setCurrentTag("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Post created!",
      description: "Your post has been shared with the campus.",
    });
    setLocation("/");
  };

  return (
    <Layout>
      <div className="p-4 max-w-lg mx-auto pb-24">
        <header className="flex items-center justify-between mb-6">
          <Button variant="ghost" size="icon" onClick={() => setLocation("/")}>
            <X size={24} />
          </Button>
          <h1 className="text-lg font-bold font-heading">New Post</h1>
          <Button onClick={handleSubmit} disabled={!content.trim()} className="rounded-full px-6">
            Post
          </Button>
        </header>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Category Selection */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">What are you posting?</Label>
            <RadioGroup defaultValue="request" onValueChange={setCategory} className="grid grid-cols-2 gap-3">
              <div>
                <RadioGroupItem value="request" id="request" className="peer sr-only" />
                <Label
                  htmlFor="request"
                  className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary cursor-pointer transition-all"
                >
                  <span className="text-2xl mb-2">🙋‍♂️</span>
                  <span className="font-bold">Request</span>
                  <span className="text-xs text-muted-foreground text-center">Ask for help or a service</span>
                </Label>
              </div>
              <div>
                <RadioGroupItem value="offer" id="offer" className="peer sr-only" />
                <Label
                  htmlFor="offer"
                  className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-emerald-500 peer-data-[state=checked]:text-emerald-600 cursor-pointer transition-all"
                >
                  <span className="text-2xl mb-2">🤝</span>
                  <span className="font-bold">Offer</span>
                  <span className="text-xs text-muted-foreground text-center">Offer your skills or help</span>
                </Label>
              </div>
              <div>
                <RadioGroupItem value="question" id="question" className="peer sr-only" />
                <Label
                  htmlFor="question"
                  className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-blue-500 peer-data-[state=checked]:text-blue-600 cursor-pointer transition-all"
                >
                  <span className="text-2xl mb-2">❓</span>
                  <span className="font-bold">Question</span>
                  <span className="text-xs text-muted-foreground text-center">Ask the community</span>
                </Label>
              </div>
              <div>
                <RadioGroupItem value="social" id="social" className="peer sr-only" />
                <Label
                  htmlFor="social"
                  className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-pink-500 peer-data-[state=checked]:text-pink-600 cursor-pointer transition-all"
                >
                  <span className="text-2xl mb-2">🎉</span>
                  <span className="font-bold">Social</span>
                  <span className="text-xs text-muted-foreground text-center">Events & hangouts</span>
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Content */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Details</Label>
            <Textarea 
              placeholder="Describe what you need or want to share..." 
              className="min-h-[150px] resize-none text-base bg-muted/30 border-muted focus:border-primary rounded-xl p-4"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
          </div>

          {/* Tags */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Tags</Label>
            <div className="flex flex-wrap gap-2 mb-2">
              {tags.map(tag => (
                <Badge key={tag} variant="secondary" className="px-3 py-1 gap-1">
                  #{tag}
                  <button onClick={() => removeTag(tag)} className="ml-1 hover:text-destructive">
                    <X size={12} />
                  </button>
                </Badge>
              ))}
            </div>
            <div className="relative">
              <Hash className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                value={currentTag}
                onChange={(e) => setCurrentTag(e.target.value)}
                onKeyDown={handleAddTag}
                placeholder="Add tags (press Enter)..." 
                className="pl-9 bg-muted/30 border-muted rounded-xl"
              />
            </div>
          </div>

          {/* Attachments (Visual Only) */}
          <div className="flex gap-4 pt-2">
            <Button type="button" variant="outline" className="flex-1 gap-2 h-12 rounded-xl text-muted-foreground hover:text-foreground">
              <ImageIcon size={20} />
              Add Photo
            </Button>
            <Button type="button" variant="outline" className="flex-1 gap-2 h-12 rounded-xl text-muted-foreground hover:text-foreground">
              <MapPin size={20} />
              Add Location
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
}
