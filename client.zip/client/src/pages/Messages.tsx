import Layout from "@/components/Layout";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";

const MOCK_CHATS = [
  {
    id: "1",
    user: { name: "Vidya", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80", online: true },
    lastMessage: "Sure, let's meet at the library at 2 PM.",
    timestamp: "10m",
    unread: 2,
  },
  {
    id: "2",
    user: { name: "Asmi", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80", online: false },
    lastMessage: "Thanks for the edit! It looks amazing.",
    timestamp: "1h",
    unread: 0,
  },
  {
    id: "3",
    user: { name: "Shruti", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80", online: false },
    lastMessage: "Did you find the gym hours?",
    timestamp: "3h",
    unread: 0,
  },
  {
    id: "4",
    user: { name: "Riddhi", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80", online: true },
    lastMessage: "I found those AirPods, checking them now.",
    timestamp: "1d",
    unread: 0,
  },
];

export default function Messages() {
  return (
    <Layout>
      <div className="h-screen flex flex-col bg-background">
        <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b px-4 py-3">
          <h1 className="text-2xl font-bold font-heading text-primary mb-4">Messages</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input 
              placeholder="Search conversations..." 
              className="pl-9 bg-muted/50 border-none h-10 rounded-xl focus-visible:ring-1 focus-visible:ring-primary/30"
            />
          </div>
        </header>

        <div className="flex-1 overflow-y-auto px-2 py-2 pb-24">
          {MOCK_CHATS.map((chat) => (
            <div 
              key={chat.id}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-accent/10 transition-colors cursor-pointer group"
            >
              <div className="relative">
                <Avatar className="h-12 w-12 border border-muted group-hover:border-primary/30 transition-colors">
                  <AvatarImage src={chat.user.avatar} />
                  <AvatarFallback className="bg-primary/5 text-primary font-bold">{chat.user.name[0]}</AvatarFallback>
                </Avatar>
                {chat.user.online && (
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-secondary border-2 border-background rounded-full"></span>
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-center mb-1">
                  <h3 className="font-bold text-sm truncate group-hover:text-primary transition-colors">{chat.user.name}</h3>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">{chat.timestamp}</span>
                </div>
                <p className={cn(
                  "text-sm truncate",
                  chat.unread > 0 ? "font-bold text-foreground" : "text-muted-foreground"
                )}>
                  {chat.lastMessage}
                </p>
              </div>

              {chat.unread > 0 && (
                <div className="bg-primary text-primary-foreground text-[10px] font-bold h-5 min-w-5 flex items-center justify-center rounded-full px-1.5 shadow-sm shadow-primary/20">
                  {chat.unread}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
