import { useState } from "react";
import Layout from "@/components/Layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, TrendingUp, Users, BookOpen, Coffee } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const TRENDING_TAGS = [
  "videoediting", "calculus", "gymbuddy", "lostandfound", "python", "design", "tutoring", "roommate"
];

const POPULAR_FREELANCERS = [
  { name: "Alex M.", role: "Graphic Designer", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80" },
  { name: "Sarah J.", role: "Video Editor", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80" },
  { name: "Mike T.", role: "Tutor (Math)", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80" },
];

export default function Explore() {
  return (
    <Layout>
      <div className="p-4 space-y-6 pb-20">
        <header>
          <h1 className="text-2xl font-bold font-heading text-primary mb-4">Explore Campus</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input 
              placeholder="Search for help, people, or events..." 
              className="pl-9 bg-white border-muted shadow-sm h-12 rounded-xl text-base"
            />
          </div>
        </header>

        {/* Trending Tags */}
        <section>
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="text-primary h-5 w-5" />
            <h2 className="text-lg font-bold">Trending Now</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {TRENDING_TAGS.map(tag => (
              <Badge 
                key={tag} 
                variant="secondary" 
                className="px-3 py-1.5 text-sm font-medium cursor-pointer hover:bg-primary/10 hover:text-primary transition-colors"
              >
                #{tag}
              </Badge>
            ))}
          </div>
        </section>

        {/* Categories Grid */}
        <section>
          <h2 className="text-lg font-bold mb-3">Browse Categories</h2>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-orange-50 p-4 rounded-xl border border-orange-100 flex flex-col items-center text-center gap-2 cursor-pointer hover:bg-orange-100 transition-colors">
              <div className="bg-white p-3 rounded-full shadow-sm text-orange-500">
                <Users size={24} />
              </div>
              <span className="font-semibold text-orange-900">Freelancers</span>
            </div>
            <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 flex flex-col items-center text-center gap-2 cursor-pointer hover:bg-blue-100 transition-colors">
              <div className="bg-white p-3 rounded-full shadow-sm text-blue-500">
                <BookOpen size={24} />
              </div>
              <span className="font-semibold text-blue-900">Study Groups</span>
            </div>
            <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 flex flex-col items-center text-center gap-2 cursor-pointer hover:bg-emerald-100 transition-colors">
              <div className="bg-white p-3 rounded-full shadow-sm text-emerald-500">
                <Coffee size={24} />
              </div>
              <span className="font-semibold text-emerald-900">Social Events</span>
            </div>
            <div className="bg-purple-50 p-4 rounded-xl border border-purple-100 flex flex-col items-center text-center gap-2 cursor-pointer hover:bg-purple-100 transition-colors">
              <div className="bg-white p-3 rounded-full shadow-sm text-purple-500">
                <Search size={24} />
              </div>
              <span className="font-semibold text-purple-900">Lost & Found</span>
            </div>
          </div>
        </section>

        {/* Featured Students */}
        <section>
          <h2 className="text-lg font-bold mb-3">Top Contributors</h2>
          <div className="flex gap-4 overflow-x-auto pb-4 -mx-4 px-4 no-scrollbar">
            {POPULAR_FREELANCERS.map((freelancer, i) => (
              <div key={i} className="min-w-[140px] bg-white border p-3 rounded-xl shadow-sm flex flex-col items-center text-center gap-2">
                <Avatar className="h-16 w-16 border-2 border-primary/20">
                  <AvatarImage src={freelancer.avatar} />
                  <AvatarFallback>{freelancer.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-bold text-sm">{freelancer.name}</div>
                  <div className="text-xs text-muted-foreground">{freelancer.role}</div>
                </div>
                <Button size="sm" variant="outline" className="w-full h-8 text-xs rounded-lg mt-1">
                  View
                </Button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
}
