import Layout from "@/components/Layout";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { MapPin, Link as LinkIcon, Calendar, Settings, Bookmark } from "lucide-react";
import { FeedCard, PostProps } from "@/components/FeedCard";

const USER_POSTS: PostProps[] = [
  {
    id: "1",
    author: { name: "You", handle: "student_dev", avatar: "https://github.com/shadcn.png" },
    content: "Looking for a study buddy for the upcoming Calc II midterm! 📚 We can meet at the main library.",
    category: "Request",
    timestamp: "2d ago",
    likes: 5,
    comments: 2,
    tags: ["calculus", "studybuddy"],
  }
];

export default function Profile() {
  return (
    <Layout>
      <div className="pb-20">
        {/* Cover Photo */}
        <div className="h-32 bg-gradient-to-r from-primary to-purple-400 w-full relative">
          <Button variant="ghost" size="icon" className="absolute top-4 right-4 text-white hover:bg-white/20">
            <Settings size={20} />
          </Button>
        </div>
        
        {/* Profile Info */}
        <div className="px-4 -mt-10 mb-6">
          <div className="flex justify-between items-end mb-4">
            <Avatar className="w-24 h-24 border-4 border-background shadow-sm">
              <AvatarImage src="https://github.com/shadcn.png" />
              <AvatarFallback>SD</AvatarFallback>
            </Avatar>
            <Button variant="outline" className="rounded-full mb-2 h-8">
              Edit Profile
            </Button>
          </div>
          
          <div>
            <h1 className="text-2xl font-bold font-heading">Alex Johnson</h1>
            <p className="text-muted-foreground">@student_dev</p>
          </div>
          
          <p className="mt-3 text-sm leading-relaxed">
            CS Major 💻 | Photographer 📸 | Always down for coffee ☕️
            <br />
            Building things for the campus community.
          </p>
          
          <div className="flex flex-wrap gap-x-4 gap-y-2 mt-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <MapPin size={14} />
              <span>North Campus</span>
            </div>
            <div className="flex items-center gap-1">
              <LinkIcon size={14} />
              <a href="#" className="text-primary hover:underline">alex.dev</a>
            </div>
            <div className="flex items-center gap-1">
              <Calendar size={14} />
              <span>Joined Sept 2023</span>
            </div>
          </div>

          <div className="flex gap-4 mt-4">
            <div className="flex items-center gap-1">
              <span className="font-bold text-foreground">142</span>
              <span className="text-sm text-muted-foreground">Following</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="font-bold text-foreground">856</span>
              <span className="text-sm text-muted-foreground">Followers</span>
            </div>
          </div>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="w-full justify-start rounded-none h-auto p-0 bg-transparent border-b px-4 gap-6">
            <TabsTrigger 
              value="posts" 
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none px-0 py-3 text-sm font-medium"
            >
              Posts
            </TabsTrigger>
            <TabsTrigger 
              value="saved" 
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none px-0 py-3 text-sm font-medium"
            >
              Saved
            </TabsTrigger>
            <TabsTrigger 
              value="reviews" 
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:shadow-none px-0 py-3 text-sm font-medium"
            >
              Reviews
            </TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="p-4 space-y-4">
             {USER_POSTS.map((post) => (
              <FeedCard key={post.id} post={post} />
            ))}
          </TabsContent>
          
          <TabsContent value="saved" className="p-8 text-center text-muted-foreground">
            <div className="flex flex-col items-center gap-2">
              <div className="p-4 bg-muted/50 rounded-full">
                <Bookmark size={24} />
              </div>
              <p>No saved posts yet</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
