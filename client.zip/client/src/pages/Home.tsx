import { useState } from "react";
import Layout from "@/components/Layout";
import { FeedCard, PostProps } from "@/components/FeedCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, Bell } from "lucide-react";

// Mock Data updated with requested names
const MOCK_POSTS: PostProps[] = [
  {
    id: "1",
    author: { name: "Asmi", handle: "asmi_arts", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80" },
    content: "🎬 Looking for a student editor who can help me with my vlogging assignment! I have about 30 mins of footage that needs to be cut down to a 5-min story. Willing to pay or trade for graphic design work!",
    category: "Request",
    timestamp: "2h ago",
    likes: 24,
    comments: 5,
    tags: ["videoediting", "vlog", "helpwanted"],
  },
  {
    id: "2",
    author: { name: "Vidya", handle: "vidya_codes", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80" },
    content: "Anyone struggling with CS101 assignments? 🖥️ I'm offering tutoring sessions this weekend at the library. We can go over Python basics and loops.",
    category: "Offer",
    timestamp: "4h ago",
    likes: 45,
    comments: 12,
    tags: ["computerscience", "tutoring", "python"],
  },
  {
    id: "3",
    author: { name: "Shruti", handle: "shruti_p", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80" },
    content: "Does anyone know if the campus gym is open during the holiday break? 🏋️‍♀️",
    category: "Question",
    timestamp: "5h ago",
    likes: 8,
    comments: 23,
    tags: ["campuslife", "gym", "question"],
  },
  {
    id: "4",
    author: { name: "Riddhi", handle: "riddhi_j", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80" },
    content: "Found a pair of AirPods in the cafeteria near the window seats. Left them with the lost & found at the front desk! 🎧",
    category: "Social",
    timestamp: "6h ago",
    likes: 89,
    comments: 2,
    tags: ["lostandfound", "campus"],
  },
];

export default function Home() {
  const [activeTab, setActiveTab] = useState("all");

  const filteredPosts = activeTab === "all" 
    ? MOCK_POSTS 
    : MOCK_POSTS.filter(post => post.category.toLowerCase() === activeTab);

  return (
    <Layout>
      {/* Header */}
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b px-4 py-3 mb-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold font-heading text-primary">Campus Connect</h1>
          <Button variant="ghost" size="icon" className="relative text-secondary hover:text-primary">
            <Bell size={20} />
            <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border border-background"></span>
          </Button>
        </div>
        
        {/* Search & Filter */}
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input 
              placeholder="Search posts, tags, or people..." 
              className="pl-9 bg-muted/50 border-none h-10 rounded-xl focus-visible:ring-1 focus-visible:ring-primary/30"
            />
          </div>
          <Button variant="outline" size="icon" className="rounded-xl shrink-0 border-muted hover:bg-accent/20 hover:text-primary">
            <Filter size={18} />
          </Button>
        </div>

        {/* Categories */}
        <Tabs defaultValue="all" onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full justify-start h-auto p-0 bg-transparent gap-2 overflow-x-auto no-scrollbar flex-nowrap">
            <TabsTrigger 
              value="all" 
              className="rounded-full border border-muted bg-background data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-4 py-1.5 h-auto text-xs font-bold"
            >
              All
            </TabsTrigger>
            <TabsTrigger 
              value="request" 
              className="rounded-full border border-muted bg-background data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:border-primary/30 px-4 py-1.5 h-auto text-xs font-bold"
            >
              Requests
            </TabsTrigger>
            <TabsTrigger 
              value="offer" 
              className="rounded-full border border-muted bg-background data-[state=active]:bg-secondary/10 data-[state=active]:text-secondary data-[state=active]:border-secondary/30 px-4 py-1.5 h-auto text-xs font-bold"
            >
              Offers
            </TabsTrigger>
            <TabsTrigger 
              value="question" 
              className="rounded-full border border-muted bg-background data-[state=active]:bg-accent/20 data-[state=active]:text-primary data-[state=active]:border-accent px-4 py-1.5 h-auto text-xs font-bold"
            >
              Questions
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </header>

      {/* Feed */}
      <div className="px-4 pb-24 space-y-4">
        {filteredPosts.map((post) => (
          <FeedCard key={post.id} post={post} />
        ))}
        
        <div className="py-8 text-center text-muted-foreground text-sm font-medium italic">
          You're all caught up! 🎉
        </div>
      </div>
    </Layout>
  );
}
